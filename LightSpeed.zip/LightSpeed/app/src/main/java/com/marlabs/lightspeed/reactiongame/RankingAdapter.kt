package com.marlabs.lightspeed.reactiongame

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RankingAdapter(private val rankingList: List<RankingRecord>) :
    RecyclerView.Adapter<RankingAdapter.RankingViewHolder>() {

    class RankingViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvRank: TextView = view.findViewById(R.id.tvRank)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvScore: TextView = view.findViewById(R.id.tvScore)
        val tvDate: TextView = view.findViewById(R.id.tvDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RankingViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_ranking, parent, false)
        return RankingViewHolder(view)
    }

    override fun onBindViewHolder(holder: RankingViewHolder, position: Int) {
        val record = rankingList[position]
        holder.tvRank.text = "#${position + 1}"
        holder.tvName.text = record.username
        holder.tvScore.text = "${record.score}ms"
        
        val sdf = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault())
        holder.tvDate.text = sdf.format(Date(record.timestamp))

        // Colores especiales para el top 3
        when (position) {
            0 -> holder.tvRank.setTextColor(android.graphics.Color.parseColor("#FFD700")) // Oro
            1 -> holder.tvRank.setTextColor(android.graphics.Color.parseColor("#C0C0C0")) // Plata
            2 -> holder.tvRank.setTextColor(android.graphics.Color.parseColor("#CD7F32")) // Bronce
            else -> holder.tvRank.setTextColor(android.graphics.Color.WHITE)
        }
    }

    override fun getItemCount() = rankingList.size
}