package com.marlabs.lightspeed.reactiongame

// Modelo de datos compatible con Firebase Firestore
data class RankingRecord(
    val username: String = "",
    val score: Long = 0,
    val timestamp: Long = 0
)