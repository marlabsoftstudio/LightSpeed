package com.marlabs.lightspeed.reactiongame

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var mainLayout: ConstraintLayout
    private lateinit var counterText: TextView
    private lateinit var statusText: TextView
    private lateinit var ratingText: TextView
    private lateinit var bestTimeText: TextView
    private lateinit var goIndicator: TextView
    private lateinit var btnRanking: Button

    // Elementos del botón de perfil
    private lateinit var menuButtonFrame: CardView
    private lateinit var menuButtonImage: ImageView
    private lateinit var menuButtonText: TextView

    private lateinit var profilesCard: CardView
    private lateinit var dynamicProfilesList: LinearLayout
    private lateinit var addProfileButton: Button

    private lateinit var lights: List<View>

    private var gameState = "idle"  // idle, countdown, green, finished
    private var activeLights = 0
    private var startTime = 0L
    private var reactionTime = 0L
    private var bestTime = Long.MAX_VALUE   // Marca personal del perfil activo

    private var currentProfile = "Jugador 1"

    private val handler = Handler(Looper.getMainLooper())
    private var countdownRunnable: Runnable? = null
    private var greenLightRunnable: Runnable? = null

    private lateinit var sharedPreferences: SharedPreferences
    private val BEST_TIME_PREFIX = "best_time_"
    private val PROFILE_IMAGE_PREFIX = "profile_image_"
    private val PROFILES_KEY = "profiles_list"
    private val CURRENT_PROFILE_KEY = "current_profile"

    private lateinit var imagePickerLauncher: ActivityResultLauncher<String>
    private var profileEditingImage: String? = null

    // Audio
    private lateinit var soundPool: SoundPool
    private var countdownSoundIds = mutableListOf<Int>()
    private var mediaPlayer: MediaPlayer? = null

    // Firebase Firestore
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance()

        // Inicializar vistas
        mainLayout = findViewById(R.id.mainLayout)
        counterText = findViewById(R.id.counterText)
        statusText = findViewById(R.id.statusText)
        ratingText = findViewById(R.id.ratingText)
        bestTimeText = findViewById(R.id.bestTimeText)
        goIndicator = findViewById(R.id.goIndicator)
        btnRanking = findViewById(R.id.btnRanking)

        // Inicializar botón de perfil
        menuButtonFrame = findViewById(R.id.menuButtonFrame)
        menuButtonImage = findViewById(R.id.menuButtonImage)
        menuButtonText = findViewById(R.id.menuButtonText)

        profilesCard = findViewById(R.id.profilesCard)
        dynamicProfilesList = findViewById(R.id.dynamicProfilesList)
        addProfileButton = findViewById(R.id.addProfileButton)

        lights = listOf(
            findViewById(R.id.light1),
            findViewById(R.id.light2),
            findViewById(R.id.light3),
            findViewById(R.id.light4),
            findViewById(R.id.light5)
        )

        // Inicializar SharedPreferences
        sharedPreferences = getSharedPreferences("LightSpeedPrefs", Context.MODE_PRIVATE)

        // Inicializar Audio
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(audioAttributes)
            .build()

        countdownSoundIds.add(soundPool.load(this, R.raw.semaforo_pitido_1, 1))
        countdownSoundIds.add(soundPool.load(this, R.raw.semaforo_pitido_2, 1))
        countdownSoundIds.add(soundPool.load(this, R.raw.semaforo_pitido_3, 1))
        countdownSoundIds.add(soundPool.load(this, R.raw.semaforo_pitido_4, 1))
        countdownSoundIds.add(soundPool.load(this, R.raw.semaforo_pitido_5, 1))

        mediaPlayer = MediaPlayer.create(this, R.raw.sonido_motor)
        mediaPlayer?.isLooping = true

        // Registrar selector de imágenes
        imagePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { saveProfileImage(it) }
        }

        loadProfiles()
        setupMenu()

        // Listener para ranking
        btnRanking.setOnClickListener {
            showRankingDialog()
        }

        // Detectar toque en toda la pantalla
        mainLayout.setOnClickListener {
            if (profilesCard.visibility == View.VISIBLE) {
                profilesCard.visibility = View.GONE
            } else {
                handleScreenPress()
            }
        }
    }

    private fun showRankingDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_ranking, null)
        val rvRanking = dialogView.findViewById<RecyclerView>(R.id.rvRanking)
        val btnClose = dialogView.findViewById<Button>(R.id.btnCloseRanking)
        
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            .setView(dialogView)
            .create()

        rvRanking.layoutManager = LinearLayoutManager(this)

        db.collection("ranking")
            .orderBy("score", Query.Direction.ASCENDING)
            .limit(25)
            .get()
            .addOnSuccessListener { result ->
                val rankingList = result.toObjects(RankingRecord::class.java)
                rvRanking.adapter = RankingAdapter(rankingList)
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar ranking: ${e.message}", Toast.LENGTH_LONG).show()
            }

        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun uploadRecordToGlobal(name: String, score: Long) {
        val record = RankingRecord(name, score, System.currentTimeMillis())

        db.collection("ranking").document(name)
            .set(record)
            .addOnSuccessListener {
                Toast.makeText(this, "¡Récord sincronizado con la nube!", Toast.LENGTH_SHORT).show()
            }
    }

    private fun saveProfileImage(uri: Uri) {
        val name = profileEditingImage ?: return
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val file = File(filesDir, "profile_${name}.jpg")
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()

            sharedPreferences.edit().putString(PROFILE_IMAGE_PREFIX + name, file.absolutePath).apply()

            val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf("Jugador 1")) ?: setOf("Jugador 1")
            updateProfilesUI(profiles)
            updateUIForCurrentProfile()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupMenu() {
        menuButtonFrame.setOnClickListener {
            profilesCard.visibility = if (profilesCard.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        addProfileButton.setOnClickListener {
            showAddProfileDialog()
        }
    }

    private fun loadProfiles() {
        val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf("Jugador 1")) ?: setOf("Jugador 1")
        currentProfile = sharedPreferences.getString(CURRENT_PROFILE_KEY, "Jugador 1") ?: "Jugador 1"

        // Asegurarse de que el perfil actual existe en la lista
        if (!profiles.contains(currentProfile)) {
            currentProfile = profiles.firstOrNull() ?: "Jugador 1"
        }

        updateProfilesUI(profiles)
        updateUIForCurrentProfile()
        updateOverallBestDisplay()
    }

    private fun updateProfilesUI(profiles: Set<String>) {
        dynamicProfilesList.removeAllViews()

        profiles.sorted().forEach { name ->
            val profileView = layoutInflater.inflate(R.layout.item_profile, dynamicProfilesList, false)
            val nameText = profileView.findViewById<TextView>(R.id.profileNameText)
            val recordText = profileView.findViewById<TextView>(R.id.profileRecordText)
            val editBtn = profileView.findViewById<ImageButton>(R.id.editProfileButton)
            val deleteBtn = profileView.findViewById<ImageButton>(R.id.deleteProfileButton)
            val textContainer = profileView.findViewById<LinearLayout>(R.id.textContainer)
            val profileImage = profileView.findViewById<ImageView>(R.id.profileImage)

            val time = sharedPreferences.getLong(BEST_TIME_PREFIX + name, Long.MAX_VALUE)
            val timeStr = if (time == Long.MAX_VALUE) "--" else "$time"

            nameText.text = name
            recordText.text = "VR Personal: $timeStr ms"

            // Cargar imagen si existe
            val imagePath = sharedPreferences.getString(PROFILE_IMAGE_PREFIX + name, null)
            if (imagePath != null && File(imagePath).exists()) {
                profileImage.setImageURI(Uri.fromFile(File(imagePath)))
            } else {
                profileImage.setImageResource(android.R.drawable.ic_menu_gallery)
            }

            profileImage.setOnClickListener {
                profileEditingImage = name
                imagePickerLauncher.launch("image/*")
            }

            textContainer.setOnClickListener {
                currentProfile = name
                sharedPreferences.edit().putString(CURRENT_PROFILE_KEY, name).apply()
                updateUIForCurrentProfile()
                profilesCard.visibility = View.GONE
            }

            editBtn.setOnClickListener {
                showEditProfileDialog(name)
            }

            deleteBtn.setOnClickListener {
                showDeleteConfirmDialog(name)
            }

            dynamicProfilesList.addView(profileView)
        }
    }

    private fun updateUIForCurrentProfile() {
        bestTime = sharedPreferences.getLong(BEST_TIME_PREFIX + currentProfile, Long.MAX_VALUE)
        btnRanking.visibility = if (bestTime != Long.MAX_VALUE) View.VISIBLE else View.GONE

        // Intentar poner la foto en el botón de perfil si existe
        val imagePath = sharedPreferences.getString(PROFILE_IMAGE_PREFIX + currentProfile, null)
        if (imagePath != null && File(imagePath).exists()) {
            menuButtonImage.visibility = View.VISIBLE
            menuButtonText.visibility = View.GONE
            menuButtonImage.setImageURI(Uri.fromFile(File(imagePath)))
        } else {
            menuButtonImage.visibility = View.GONE
            menuButtonText.visibility = View.VISIBLE
            menuButtonText.text = currentProfile.take(1).uppercase()
        }
    }

    private fun updateOverallBestDisplay() {
        val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf("Jugador 1")) ?: setOf("Jugador 1")
        var overallBest = Long.MAX_VALUE
        var bestPlayer = ""

        profiles.forEach { name ->
            val time = sharedPreferences.getLong(BEST_TIME_PREFIX + name, Long.MAX_VALUE)
            if (time < overallBest) {
                overallBest = time
                bestPlayer = name
            }
        }

        if (overallBest != Long.MAX_VALUE) {
            bestTimeText.text = "🏆 VR de Carrera: $bestPlayer {${overallBest}ms}"
            bestTimeText.textSize = 15f
        } else {
            bestTimeText.text = "🏆 Sin récords aún"
            bestTimeText.textSize = 18f
        }
    }

    private fun showAddProfileDialog() {
        val editText = EditText(this)
        editText.hint = "Nombre del piloto"

        AlertDialog.Builder(this)
            .setTitle("Nuevo Piloto")
            .setView(editText)
            .setPositiveButton("Inscribir") { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotEmpty()) {
                    val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf("Jugador 1"))?.toMutableSet() ?: mutableSetOf("Jugador 1")
                    profiles.add(name)
                    sharedPreferences.edit().putStringSet(PROFILES_KEY, profiles).apply()

                    currentProfile = name
                    sharedPreferences.edit().putString(CURRENT_PROFILE_KEY, name).apply()

                    updateProfilesUI(profiles)
                    updateUIForCurrentProfile()
                    updateOverallBestDisplay()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showEditProfileDialog(oldName: String) {
        val editText = EditText(this)
        editText.setText(oldName)

        AlertDialog.Builder(this)
            .setTitle("Editar Piloto")
            .setView(editText)
            .setPositiveButton("Guardar") { _, _ ->
                val name = editText.text.toString().trim()
                if (name.isNotEmpty() && name != oldName) {
                    val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf())?.toMutableSet() ?: mutableSetOf()
                    if (profiles.contains(oldName)) {
                        profiles.remove(oldName)
                        profiles.add(name)

                        // Mover el récord y la imagen
                        val savedTime = sharedPreferences.getLong(BEST_TIME_PREFIX + oldName, Long.MAX_VALUE)
                        val savedImage = sharedPreferences.getString(PROFILE_IMAGE_PREFIX + oldName, null)

                        sharedPreferences.edit().apply {
                            putStringSet(PROFILES_KEY, profiles)
                            remove(BEST_TIME_PREFIX + oldName)
                            remove(PROFILE_IMAGE_PREFIX + oldName)
                            putLong(BEST_TIME_PREFIX + name, savedTime)
                            if (savedImage != null) putString(PROFILE_IMAGE_PREFIX + name, savedImage)

                            if (currentProfile == oldName) {
                                putString(CURRENT_PROFILE_KEY, name)
                                currentProfile = name
                            }
                        }.apply()

                        updateProfilesUI(profiles)
                        updateUIForCurrentProfile()
                        updateOverallBestDisplay()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showDeleteConfirmDialog(name: String) {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Piloto")
            .setMessage("¿Estás seguro de que quieres eliminar a $name? Se perderán todos sus récords.")
            .setPositiveButton("Eliminar") { _, _ ->
                val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf())?.toMutableSet() ?: mutableSetOf()
                if (profiles.size > 1) {
                    profiles.remove(name)

                    // Borrar archivo de imagen si existe
                    val imagePath = sharedPreferences.getString(PROFILE_IMAGE_PREFIX + name, null)
                    imagePath?.let { File(it).delete() }

                    sharedPreferences.edit().apply {
                        putStringSet(PROFILES_KEY, profiles)
                        remove(BEST_TIME_PREFIX + name)
                        remove(PROFILE_IMAGE_PREFIX + name)
                        if (currentProfile == name) {
                            val nextProfile = profiles.first()
                            putString(CURRENT_PROFILE_KEY, nextProfile)
                            currentProfile = nextProfile
                        }
                    }.apply()

                    updateProfilesUI(profiles)
                    updateUIForCurrentProfile()
                    updateOverallBestDisplay()
                } else {
                    // No permitir borrar el último perfil
                    AlertDialog.Builder(this)
                        .setMessage("Debe haber al menos un piloto inscrito.")
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun handleScreenPress() {
        when (gameState) {
            "idle" -> startGame()
            "countdown" -> handleFalseStart()
            "green" -> stopTimer()
        }
    }

    private fun startGame() {
        gameState = "countdown"
        activeLights = 0
        reactionTime = 0
        counterText.text = "0"
        statusText.text = "⚠️ Espera..."
        ratingText.text = ""
        goIndicator.visibility = View.GONE

        // Apagar todas las luces
        lights.forEach { it.setBackgroundResource(R.drawable.light_off_big) }

        // Encender luces progresivamente
        countdownRunnable = object : Runnable {
            override fun run() {
                if (activeLights < 5) {
                    if (countdownSoundIds.size > activeLights) {
                        soundPool.play(countdownSoundIds[activeLights], 1f, 1f, 0, 0, 1f)
                    }
                    lights[activeLights].setBackgroundResource(R.drawable.light_on_big)
                    activeLights++
                    handler.postDelayed(this, 600)
                } else {
                    // Todas las luces encendidas, espera aleatoria
                    val randomDelay = (500..5000).random().toLong()
                    greenLightRunnable = Runnable {
                        showGreenLight()
                    }
                    handler.postDelayed(greenLightRunnable!!, randomDelay)
                }
            }
        }
        handler.post(countdownRunnable!!)
    }

    private fun showGreenLight() {
        gameState = "green"

        mediaPlayer?.start()

        // Apagar todas las luces
        lights.forEach { it.setBackgroundResource(R.drawable.light_off_big) }

        // Mostrar indicador verde
        goIndicator.visibility = View.VISIBLE

        statusText.text = "🏁 ¡TOCA AHORA!"
        startTime = System.currentTimeMillis()

        // Actualizar contador en tiempo real
        val counterUpdateRunnable = object : Runnable {
            override fun run() {
                if (gameState == "green") {
                    val elapsedTime = System.currentTimeMillis() - startTime
                    if (elapsedTime >= 999999) {
                        counterText.text = "999.999"
                    } else {
                        val seconds = elapsedTime / 1000
                        val milliseconds = elapsedTime % 1000
                        counterText.text = String.format("%d.%03d", seconds, milliseconds)
                    }
                    handler.postDelayed(this, 10)
                }
            }
        }
        handler.post(counterUpdateRunnable)
    }

    private fun stopTimer() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
            mediaPlayer?.seekTo(0)
        }
        val endTime = System.currentTimeMillis()
        reactionTime = endTime - startTime
        if (reactionTime >= 999999) {
            reactionTime = 999999
        }
        gameState = "finished"

        counterText.text = reactionTime.toString()
        goIndicator.visibility = View.GONE

        // Mostrar valoración
        val rating = getReactionRating(reactionTime)
        ratingText.text = rating.first
        ratingText.setTextColor(Color.parseColor(rating.second))

        statusText.text = "✨ Toca para intentar de nuevo"

        // Actualizar mejor tiempo del perfil actual
        if (reactionTime < bestTime) {
            bestTime = reactionTime
            sharedPreferences.edit().putLong(BEST_TIME_PREFIX + currentProfile, bestTime).apply()

            // Subir a Firebase Firestore
            uploadRecordToGlobal(currentProfile, bestTime)

            // Refrescar UI del menú y el trofeo global
            val profiles = sharedPreferences.getStringSet(PROFILES_KEY, setOf("Jugador 1")) ?: setOf("Jugador 1")
            updateProfilesUI(profiles)
            updateOverallBestDisplay()
        }

        // Resetear después de 3 segundos
        handler.postDelayed({ reset() }, 3000)
    }

    private fun handleFalseStart() {
        if (mediaPlayer?.isPlaying == true) {
            mediaPlayer?.pause()
            mediaPlayer?.seekTo(0)
        }
        gameState = "finished"
        handler.removeCallbacks(countdownRunnable!!)
        greenLightRunnable?.let { handler.removeCallbacks(it) }

        counterText.text = "¡FALTA!"
        counterText.setTextColor(Color.RED)
        statusText.text = "❌ Salida en falso - Toca para reintentar"
        ratingText.text = ""

        handler.postDelayed({
            counterText.setTextColor(Color.parseColor("#00BCD4"))
            reset()
        }, 3000)
    }

    private fun reset() {
        gameState = "idle"
        activeLights = 0
        counterText.text = "0"
        statusText.text = "📱 Toca la pantalla para comenzar"
        ratingText.text = ""
        goIndicator.visibility = View.GONE
        lights.forEach { it.setBackgroundResource(R.drawable.light_off_big) }
    }

    private fun getReactionRating(time: Long): Pair<String, String> {
        return when {
            time < 200 -> Pair("¡Increíble!", "#FFD700")
            time < 300 -> Pair("¡Excelente!", "#4CAF50")
            time < 400 -> Pair("Muy Bien", "#2196F3")
            time < 500 -> Pair("Bien", "#9E9E9E")
            else -> Pair("Puedes mejorar", "#F44336")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()
        mediaPlayer?.release()
        mediaPlayer = null
        countdownRunnable?.let { handler.removeCallbacks(it) }
        greenLightRunnable?.let { handler.removeCallbacks(it) }
    }
}