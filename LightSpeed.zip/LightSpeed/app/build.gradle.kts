import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.google.services)
}

// Cargar propiedades de firma desde local.properties en la raíz
val keystorePropertiesFile = rootProject.file("local.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(keystorePropertiesFile.inputStream())
}

android {
    /**
     * namespace = "com.marlabs.lightspeed.reactiongame"
     * compileSdk {
     *     version = release(36) {
     *         minorApiLevel = 1
     *     }
     * }
     */
    namespace = "com.marlabs.lightspeed.reactiongame"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.marlabs.lightspeed.reactiongame"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "2.08"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            // Usamos rootProject.file para que la ruta relativa funcione correctamente. La ruta parte/comienza desde la raíz del proyecto.
            val path = keystoreProperties["signing.storeFile"] as String?
            if (path != null) {
                storeFile = rootProject.file(path)
            }
            storePassword = keystoreProperties["signing.storePassword"] as String?
            keyAlias = keystoreProperties["signing.keyAlias"] as String?
            keyPassword = keystoreProperties["signing.keyPassword"] as String?
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true 
            
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")

            // Configuración avanzada para símbolos de depuración. Para solucionar el aviso de código nativo (Firebase)
            ndk {
                debugSymbolLevel = "FULL"
            }
        }
    }

    // Forzar que los símbolos nativos no se compriman para que Google Play los lea bien
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Firebase Firestore para comunicaciones con la base de datos Firebase.
    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.firestore)
    implementation(libs.firebase.analytics)

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}